# Festem
Feature selection by EM test

Current this is a pre-release version of Festem.

For analysis codes for paper "Directly selecting differentially expressed genes for single-cell clustering analyses", see https://github.com/XiDsLab/Festem_paper.
